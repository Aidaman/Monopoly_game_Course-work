﻿#include <SFML/Graphics.hpp> //Подключение графической библиотеки, для рисования
#include<string>
#include<iostream>
#include<ctime>
#include<conio.h>
#include<windows.h>
#include<thread>
#include<fstream>
#include"Map.h"
#include"Button.h"
#include"Dice.h"
#include"Player.h"

using namespace std;
using namespace sf;
//tip: Название переменной + О = первое (что-то one)
//tip: Название переменной + Т = второе (что-то two)
const string fontF = "Arial.ttf";


int GenerateRandom() //Функция генерирующая случайные числа, выпаадающие на кубиках
{
	int j;
	for (int i = 0; i < 6; i++)
	{
	srand(time(NULL));
	j = rand() % 6 + 1;
	Sleep(100);
	}
	return j;
}

Color chooseColor(RenderWindow& contextWindow, Map& menu, Button& PlayerVsBot, Button& PlayerVsPlayer) //Функция, которая осуществляет выбор цвета фигурки игрока
{
	vector<Button> sprites; //Вектор спрайтов для иконок цвета
	Color colors[6]
	{
		Color(153, 255, 153, 255),
		Color(150, 20, 60, 255),
		Color(250, 0, 250, 255),
		Color(255, 128, 0, 255),
		Color(200, 162, 200, 255),
		Color(48, 213, 200, 255), //Массив имеющихся цветов
	};

	int xPos = 20, yPos = 40, k = 0;
	for (int i = 0; i < 6; i++)
	{
		Button ColorChooseButton("buttontmp", xPos, yPos = 40+k*100);
		k++;
		ColorChooseButton.setColor(colors[i]);
		if (i == 2) { xPos += 420; yPos = 0; k = 0; }
		sprites.push_back(ColorChooseButton);
	}

	while (true)
	{
		for (int i = 0; i < sprites.size(); i++) //Устанавливаем стандартные цвета кнопкам
		{
			sprites[i].setColor(colors[i]);
		}

		sf::Event event;
		while (contextWindow.pollEvent(event)) //Отслеживание нажатия "крестика"
		{

			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				contextWindow.close(); //Окно закрыватся
		}
		if (IntRect(20, 40, 100, 100).contains(Mouse::getPosition(contextWindow))) //Проверяем на наличие в одном из квадратов курсора
		{
			sprites[0].setColor(Color(183, 255, 153, 200)); //При наличии выделяем выбранную кнопку
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[0]; //При нажатии на кнопку возвращаем цвет
			}
		}
		if (IntRect(20, 140, 100, 100).contains(Mouse::getPosition(contextWindow))) //Тоже самое ещё 5 раз
		{
			sprites[1].setColor(Color(150, 60, 60, 200));
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[1];
			}
		}
		if (IntRect(20, 240, 100, 100).contains(Mouse::getPosition(contextWindow)))
		{
			sprites[2].setColor(Color(250, 60, 250, 200));
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[2];
			}
		}
		if (IntRect(440, 40, 100, 100).contains(Mouse::getPosition(contextWindow)))
		{
			sprites[3].setColor(Color(255, 188, 0, 200));
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[3];
			}
		}
		if (IntRect(440, 140, 100, 100).contains(Mouse::getPosition(contextWindow)))
		{
			sprites[4].setColor(Color(200, 162, 250, 200));
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[4];
			}
		}
		if (IntRect(440, 240, 100, 100).contains(Mouse::getPosition(contextWindow)))
		{
			sprites[5].setColor(Color(48, 213, 250, 200));
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				return colors[5];
			}
		}
		contextWindow.clear();
		contextWindow.draw(menu.getSprite());
		for (int i = 0; i < sprites.size(); i++)
		{
			contextWindow.draw(sprites[i].getSprite());
		}
		contextWindow.draw(PlayerVsBot.getSprite());
		contextWindow.draw(PlayerVsPlayer.getSprite());

		contextWindow.display();

	}
}

string chooseSprite(RenderWindow& contextWindow, Map& menu, Button& PlayerVsBot, Button& PlayerVsPlayer) //Метод для выбора спрайта Игрока
{
	vector<string> filenames{ "Players/Sombrero.png" , "Players/Carreta.png" , "Players/Carro.png" , "Players/Perro.png" , "Players/Plancha.png" , "Players/Barco.png" }; //Вектор имён файлов
	vector<Texture> textures(6); //Вектор текстур и спрайтов
	vector<Sprite> sprites;
	int xSpritePos = 30;
	Texture shape1; shape1.loadFromFile("Stuff/shape1.png"); //Достаём отдельную текстуру/спрайт, для колечка, выделяющего выбираемый спрайт
	Sprite ChoseShape; ChoseShape.setTexture(shape1);

	Font MyFont;
	MyFont.loadFromFile(fontF);

	Text askingInfo("", MyFont, 20); //Текст, с информацией, которую мы будем выводить на экран
	askingInfo.setString("Choose your figure");
	askingInfo.setFillColor(Color(150, 0, 150));
	askingInfo.setPosition(30, 30);

	for (int i = 0; i < 6; i++)
	{
		Sprite tmpSprite;
		textures[i].loadFromFile(filenames[i]); //Заполняем вектор с спрайтами, заданными текстурами, и задаём им сразу координаты
		tmpSprite.setTexture(textures[i]);
		tmpSprite.setPosition(xSpritePos += 100, 80);
		sprites.push_back(tmpSprite);
	}
	string toReturn;
	while (toReturn.size() < 1)
	{
		contextWindow.clear();
		contextWindow.draw(menu.getSprite());

		contextWindow.draw(askingInfo);
		for (int i = 0; i < sprites.size(); i++)
		{
			contextWindow.draw(sprites[i]);
		}

		contextWindow.draw(PlayerVsBot.getSprite());
		contextWindow.draw(PlayerVsPlayer.getSprite()); //Отрисовываем все спрайты, и меню

		sf::Event event;
		while (contextWindow.pollEvent(event)) //Отслеживание нажатия "крестика"
		{

			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				contextWindow.close(); //Окно закрыватся
		}

		if (IntRect(130, 80, 85, 85).contains(Mouse::getPosition(contextWindow))) //Проверяем курсор на наличие в каком-то секторе
		{
			ChoseShape.setPosition(120, 60); //Устанавливаем кружочку-выделителю позицию, и отрисовываем его
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[0]; //Осуществляем выбор
				//Unbreak = true;
			}
		}
		if (IntRect(230, 80, 85, 85).contains(Mouse::getPosition(contextWindow))) //Тоже самое ещё 5 раз
		{
			ChoseShape.setPosition(220, 60);
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[1];
				//Unbreak = true;
			}
		}
		if (IntRect(330, 80, 85, 85).contains(Mouse::getPosition(contextWindow)))
		{
			ChoseShape.setPosition(320, 60);
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[2];
				//Unbreak = true;
			}
		}
		if (IntRect(430, 80, 85, 85).contains(Mouse::getPosition(contextWindow)))
		{
			ChoseShape.setPosition(410, 60);
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[3];
				//Unbreak = true;
			}
		}
		if (IntRect(530, 80, 85, 85).contains(Mouse::getPosition(contextWindow)))
		{
			ChoseShape.setPosition(520, 60);
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[4];
				//Unbreak = true;
			}
		}
		if (IntRect(630, 80, 85, 85).contains(Mouse::getPosition(contextWindow)))
		{
			ChoseShape.setPosition(620, 60);
			contextWindow.draw(ChoseShape);
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				toReturn = filenames[5];
				//Unbreak = true;
			}
		}
		
		if (Mouse::isButtonPressed(Mouse::Button::Left) || Mouse::isButtonPressed(Mouse::Button::Right) || Mouse::isButtonPressed(Mouse::Button::Middle))
		{
			cout << "User clicked not in the rectangle" << endl;
			Sleep(100);
		}

		contextWindow.display(); //Отобпражаем
	}
	return toReturn;
}

string inputName(RenderWindow& contextWindow, Map& menu, Button& PlayerVsBot, Button& PlayerVsPlayer) //Метод для ввода имени
{
	sf::Font MyFont;
	MyFont.loadFromFile(fontF);
	Text name__("", MyFont, 20);
	name__.setPosition(30, 30); //Создаём текст, который будет отображать введённое имя

	Text askingInfo("", MyFont, 20);
	askingInfo.setPosition(30, 30);
	askingInfo.setString("Input Player name (To accept press Enter): ");
	askingInfo.setFillColor(Color(150, 0, 150)); //Текст, для запроса имени
	string str; //Строка которую будем заполнять
	while (str.size() < 20)
	{
		name__.setString(str);
		name__.setPosition(30, 30);
		name__.setFillColor(sf::Color(150, 0, 150));
		askingInfo.setString("Input Player name (To accept press Enter): " + str);
		sf::Event event;
		while (contextWindow.pollEvent(event))
		{
			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				contextWindow.close(); //Окно закрыватся
			if (event.type == sf::Event::TextEntered && str.size() < 20) //Проверка на ввод с клавиатуры
			{
				if (event.text.unicode < 128 && str.size() < 20) //Добавляем введённое с клавиатуры значение, если оно в кодировке ASCI, и размер строки меньше чем 20
				{
					str += static_cast<char>(event.text.unicode);
					cout << "Char entered! " << str << endl;
				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Backspace) && str.size() != 1) //Если нажимаем бекспейс и строка не будет меньше нуля
				{
					str.pop_back(); //Удаляем терминирующий ноль
					str.pop_back(); //Удаляем символ
					cout << "Char erased! " << str << endl; //Даём отчёт в консоль разработчика
				}
			}
		}
		contextWindow.clear();
		contextWindow.draw(menu.getSprite());
		contextWindow.draw(PlayerVsBot.getSprite());
		contextWindow.draw(PlayerVsPlayer.getSprite());
		contextWindow.draw(askingInfo);
		contextWindow.display(); //Отображаем
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && str.size() > 0)
		{
			break; //Условие выхода
		}
	}
	return str;
}


void firstMenu(Player& player1, Player& player2) //Функция отвечающая за первое меню в программе
{
	sf::Font MyFont;
	MyFont.loadFromFile(fontF);
	Text name__("", MyFont, 20);
	name__.setPosition(60, 30);
	
	RenderWindow MenuWi(VideoMode(820, 820), "MyMonopoly");

	Map menu("Monopoly-Logo-HR_result");
	Button PlayerVsBot("plbot", 30, 670);
	Button PlayerVsPlayer("plpl", 440, 670);
	sf::Text Attention("Attention, if you will close window the game will start in standart mode:\nplayer name: player\ngamemode: PvE\nplayer color: purple", MyFont, 20);
	Attention.setPosition(30, 10);
	Attention.setFillColor(sf::Color(150,20,0)); //Создаём текста, 2 кнопки. Один из текстов - предупреждение

	while (MenuWi.isOpen())
	{
		MenuWi.clear();
		PlayerVsBot.setColor(sf::Color(150, 20, 0));
		PlayerVsPlayer.setColor(sf::Color(150, 20, 0));


		sf::Event event;
		while (MenuWi.pollEvent(event)) //Отслеживание нажатия "крестика"
		{

			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				MenuWi.close(); //Окно закрыватся
		}
		if (IntRect(30, 670, 350, 100).contains(Mouse::getPosition(MenuWi))) // Отслеживаем курсор
		{
			PlayerVsBot.setColor(sf::Color(50, 150, 0));
			if (Mouse::isButtonPressed(Mouse::Button::Left)) //Если нажата ЛКМ на секоре с выбором PvE
			{
				player1.setName(inputName(MenuWi, menu, PlayerVsBot, PlayerVsPlayer)); //То мы регистрируем только одного пользователя, а второй - бот
				player1.setBotStatus(false);
				Sleep(100);
				player1.setSprite(chooseSprite(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);
				player1.setSpriteColor(chooseColor(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);
				player2.setBotStatus(true);
				player2.setSpriteColor(sf::Color(0, 191, 255, 255));

				break;
			}
		}
		if (IntRect(440, 670, 350, 100).contains(Mouse::getPosition(MenuWi)))
		{
			PlayerVsPlayer.setColor(sf::Color(50, 150, 0)); //Если кнопка нажата на PvP, то регистрируем всех двух игроков
			if (Mouse::isButtonPressed(Mouse::Button::Left))
			{
				player1.setName(inputName(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				player1.setBotStatus(false);
				Sleep(100);
				player1.setSprite(chooseSprite(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);
				player1.setSpriteColor(chooseColor(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);
				player2.setName(inputName(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				player2.setBotStatus(false);
				Sleep(100);
				player2.setSprite(chooseSprite(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);
				player2.setSpriteColor(chooseColor(MenuWi, menu, PlayerVsBot, PlayerVsPlayer));
				Sleep(100);

				break;
			}
		}

		
		MenuWi.draw(menu.getSprite());
		MenuWi.draw(Attention);
		MenuWi.draw(PlayerVsBot.getSprite());
		MenuWi.draw(PlayerVsPlayer.getSprite());
		MenuWi.display();
	}
}

int main() //Вход в програму. Тут проходит игра
{
	Player::InitAllStuff();
	Player::InitAllChances(); //Инициализируем статические векторы, в которых будут хранится Клетки-сюрпризы, и все клетки в принципе

	Player _Player("Sombrero.png", false, "Player");
	Player _bot("Carro.png", false, "Bot");
	firstMenu(_Player, _bot); //Инициализируем игроков
	
	sf::RenderWindow window(sf::VideoMode(1400, 1000), "MyMonopoly");
	
	int rndNumberO = GenerateRandom();
	int rndNumberT = GenerateRandom(); //Переменные, которые будут отображать выпавшие числа на костях
	bool buttonIdentifier = false;
	
	Dice diceO(460, 700);
	Dice diceT(560, 700);
	Button _button("ThrowDice", 510, 800);
	Button _exit("Exit", 170, 200);
	Map _map("map1"); //Кости, карта, кнопка для броска костей
	
	sf::Font MyFont;
	MyFont.loadFromFile("Arial.ttf");
	sf::Text someinfo(_Player.getInfo(), MyFont, 16); 
	someinfo.setPosition(1050, 10);

	sf::Text moreinfo(_bot.getInfo(), MyFont, 16); //Тексты для вывода информации об игроках
	moreinfo.setPosition(1050, 510);
	int turn = 0;
	for (int b = 0; window.isOpen();)
	{
		window.clear();
		window.draw(_map.getSprite());

		sf::Event event;
		_button.setColor(sf::Color(0, 200, 0));
		_exit.setColor(Color(200, 0, 0));
		while (window.pollEvent(event)) //Отслеживание нажатия "крестика"
		{
			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				window.close(); //Окно закрыватся
		}
		if (IntRect(510, 800, 88, 65).contains(Mouse::getPosition(window)))
		{
			_button.setColor(sf::Color(0, 255, 0)); //buttonIdentifier = true;
			if (Mouse::isButtonPressed(Mouse::Left)) //Осуществляем ход
			{
				++b;
				srand(time(NULL));
				rndNumberO = GenerateRandom();
				Sleep(10);
				rndNumberT = GenerateRandom(); //Генерирую рандомно числа

				cout << "Player one:" << rndNumberO << endl;
				cout << "Player two:" << rndNumberT << endl;
				for (int i = 0; i < 6; i++)
				{
					int j1 = rand() % 6 + 1;
					int j2 = rand() % 6 + 1;
					srand(time(NULL));
					window.clear();
					window.draw(_map.getSprite());
					window.draw(diceT.getSprite(j2));
					window.draw(diceO.getSprite(j1)); 

					window.draw(_Player.getSprite()); //После всего, я заново отрисовываю игрока
					window.draw(_bot.getSprite()); //После всего, я заново отрисовываю игрока
					someinfo.setString(_Player.getInfo());
					moreinfo.setString(_bot.getInfo());
					window.draw(someinfo);
					window.draw(moreinfo);
					window.display();
					Sleep(200 - (i * 15));
				}
				/*до движения*/
				window.clear();
				window.draw(_map.getSprite());
				window.draw(diceT.getSprite(rndNumberO));
				window.draw(diceO.getSprite(rndNumberT)); //Отрисовываю стороны кубиков ассоциируемую с этим числом 
				window.draw(someinfo);
				window.draw(moreinfo);
				_Player.moove(rndNumberO + rndNumberT); //Двигаю игрока на полученное числоа 

				/*после движения*/
				window.draw(_Player.getSprite()); //После всего, я заново отрисовываю игрока
				window.draw(_bot.getSprite()); //После всего, я заново отрисовываю игрока
				window.display();

				_Player.askForPosess(_Player.findElement(_Player.getPosition())/*, _bot*/);
				_Player.payFee(_Player.findElement(_Player.getPosition()), _bot);

				someinfo.setString(_Player.getInfo());
				moreinfo.setString(_bot.getInfo());

				window.draw(someinfo);
				window.draw(moreinfo);

				Sleep(500);

				/*Теперь тоже самое для бота*/
				srand(time(NULL));
				rndNumberO = GenerateRandom();
				Sleep(10);
				rndNumberT = GenerateRandom(); //Генерирую рандомно числа
				cout << "Bot one:" << rndNumberO << endl;
				cout << "Bot two:" << rndNumberT << endl;
				for (int i = 0; i < 6; i++)
				{
					int j1 = rand() % 6 + 1;
					int j2 = rand() % 6 + 1;
					srand(time(NULL));
					window.clear();
					window.draw(_map.getSprite());
					window.draw(diceT.getSprite(j2));
					window.draw(diceO.getSprite(j1)); //Отрисовываю стороны кубиков ассоциируемую с этим числом /*до движения*/
					window.draw(_Player.getSprite()); //После всего, я заново отрисовываю игрока
					window.draw(_bot.getSprite()); //После всего, я заново отрисовываю игрока
					someinfo.setString(_Player.getInfo());
					moreinfo.setString(_bot.getInfo());
					window.draw(someinfo);
					window.draw(moreinfo);
					window.display();
					Sleep(200 - (i * 15));
				}
				/*до движения*/
				window.clear();
				window.draw(_map.getSprite());
				window.draw(diceT.getSprite(rndNumberO));
				window.draw(diceO.getSprite(rndNumberT)); //Отрисовываю стороны кубиков ассоциируемую с этим числом 
				window.draw(someinfo);
				window.draw(moreinfo);
				_bot.moove(rndNumberO + rndNumberT); //Двигаю игрока на полученное числоа 

				/*после движения*/
				window.draw(_Player.getSprite()); //После всего, я заново отрисовываю игрока
				window.draw(_bot.getSprite()); //После всего, я заново отрисовываю игрока
				window.display();

				_bot.askForPosess(_bot.findElement(_bot.getPosition())/*, _Player*/);
				_bot.payFee(_bot.findElement(_bot.getPosition()), _Player);

				someinfo.setString(_Player.getInfo());
				moreinfo.setString(_bot.getInfo());

				window.draw(someinfo);
				window.draw(moreinfo);

			}
				
		}
		if (IntRect(170, 200, 88, 65).contains(Mouse::getPosition(window)))
		{
			_exit.setColor(sf::Color(255, 0, 0)); //buttonIdentifier = true;
			if (Mouse::isButtonPressed(Mouse::Left)) //Осуществляем ход
			{
				buttonIdentifier = true;
			}
		}

		window.draw(diceT.getSprite(rndNumberT));
		window.draw(diceO.getSprite(rndNumberO)); //Отрисовываю стороны кубиков ассоциируемую с этим числом
		window.draw(_Player.getSprite()); //После всего, я заново отрисовываю игрока
		window.draw(_bot.getSprite()); //После всего, я заново отрисовываю игрока
		window.draw(_button.getSprite());
		window.draw(_exit.getSprite());
		
		someinfo.setString(_Player.getInfo());
		moreinfo.setString(_bot.getInfo());

		window.draw(someinfo);
		window.draw(moreinfo);

		window.display();
		if (_Player.getBalance() < 1 || _bot.getBalance() < 1 || _Player.getBalance() > 2500 || _bot.getBalance() > 2500 || buttonIdentifier == true)
		{
			turn = b;
			window.close();
		}
	}
	
	ofstream save("Records.txt", ios::app);
	
	if (_Player.getBalance() < _bot.getBalance())
	{
		save << _bot.getName() << " win \nscore: " << _bot.getBalance() << " On turn " << turn << "\n";
	}
	else
	{
		save << _Player.getName() << " win \nscore: " << _bot.getBalance() << " On turn " << turn << "\n";
	}
	
	string records;
	ifstream load("Record.txt");
	while (!load.eof())
	{
		getline(load, records);
	}
	someinfo.setPosition(20, 20);
	someinfo.setString(records);
	RenderWindow recordtable(VideoMode(1000, 1000), "Records");
	while (recordtable.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event)) //Отслеживание нажатия "крестика"
		{
			if (event.type == sf::Event::Closed) //И если тип Event совпадает с нажатием крестика
				window.close(); //Окно закрыватся
		}

		recordtable.clear();
		recordtable.draw(someinfo);
		recordtable.display();
	}

	return 0;
}