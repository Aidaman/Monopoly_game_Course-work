#include "Map.h"

Map::Map(string f)
{
	_map_texture.loadFromFile("Stuff/"+f+".jpg");
	_map.setTexture(_map_texture);
}

sf::Sprite Map::getSprite()
{
	return _map;
}
