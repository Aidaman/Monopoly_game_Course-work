#include "ChanceUnit.h"

Chance::Chance(int Give, int Take, int Moove, bool Stun) : _toGive{ Give }, _toTake{ Take }, _toMooveTo{ Moove }, _toStun{ Stun }
{
}

Chance::Chance()
{
}

int Chance::getGift()
{
    return _toGive;
}

int Chance::getTake()
{
    return _toTake;
}

int Chance::getMooveTo()
{
    return _toMooveTo;
}

bool Chance::getStun()
{
    return _toStun;
}

void Chance::setGift(int val)
{
    _toGive = val;
}

void Chance::setTake(int val)
{
    _toTake = val;
}

void Chance::setMooveTo(int val)
{
    _toMooveTo = val;
}

void Chance::setStun(bool val)
{
    _toStun = val;
}
