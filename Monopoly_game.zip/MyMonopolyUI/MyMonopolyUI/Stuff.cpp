#include "Stuff.h"

Stuff::Stuff()
{}

Stuff::Stuff(int position) : _position{position}
{}

Stuff::Stuff(int position, int price, int income, string name) : _position{position}, _price{price}, _income{income}, _name{name}
{}

int Stuff::getPrice()
{
	return _price;
}

int Stuff::getIncome()
{
	return _income;
}

int Stuff::getPosition()
{
	return _position;
}

string Stuff::getName()
{
	return _name;
}

bool Stuff::getPosess()
{
	return _isPosessed;
}

bool Stuff::getRandomness()
{
	return _isRandom;
}

void Stuff::setPrice(int value)
{
	_price = value;
}

void Stuff::setIncome(int value)
{
	_income = value;
}

void Stuff::setName(string value)
{
	_name = value;
}

void Stuff::setPosess(bool value)
{
	_isPosessed = value;
}

void Stuff::setRandomnes(bool value)
{
	_isRandom = value;
}

int Stuff::giveIncome()
{
	return _income/**_upgrade*/;
}

bool Stuff::operator==(const Stuff& unit)
{
	if (this->_price == unit._price && this->_income == unit._income && this->_name == unit._name && this->_position == unit._position)
	{
		return true;
	}
	else
	{
		return false;
	}
}
