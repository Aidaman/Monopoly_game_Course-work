#include "Button.h"

Button::Button(string f, int coord_x, int coord_y) : _buttonName{ f }, coordinate_x{ coord_x }, coordinate_y{ coord_y }
{
	_buttonTexture.loadFromFile("Stuff/" + f + ".png");
	_buttonSprite.setTexture(_buttonTexture);
	_buttonSprite.setPosition(coordinate_x, coordinate_y);
}

sf::Sprite Button::getSprite()
{
	_buttonSprite.setPosition(coordinate_x, coordinate_y);
	return _buttonSprite;
}

void Button::setColor(sf::Color color)
{
	_buttonSprite.setColor(color);
}
